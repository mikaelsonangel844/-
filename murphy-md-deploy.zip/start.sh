#!/bin/bash
echo "🚀 Démarrage du bot Murphy-MD..."
while true; do
  node index.js
  echo "⚠️ Le bot a crashé ! Redémarrage dans 5 secondes..."
  sleep 5
done
