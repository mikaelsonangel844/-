const axios = require("axios");

const API_URL = "https://control.bot-hosting.net/api/client/servers/TON_SERVEUR_ID/power";
const API_KEY = process.env.BOT_HOSTING_API_KEY;

async function restartBot() {
    try {
        await axios.post(API_URL, { signal: "restart" }, {
            headers: { Authorization: `Bearer ${API_KEY}`, "Content-Type": "application/json" }
        });
        console.log("✅ Bot redémarré avec succès !");
    } catch (error) {
        console.error("❌ Erreur lors du redémarrage :", error.response ? error.response.data : error.message);
    }
}

restartBot();
